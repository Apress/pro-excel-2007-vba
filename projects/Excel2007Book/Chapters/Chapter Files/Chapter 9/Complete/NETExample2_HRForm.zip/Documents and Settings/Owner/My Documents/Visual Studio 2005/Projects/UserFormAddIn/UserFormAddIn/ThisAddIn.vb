
public class ThisAddIn

    Private Sub ThisAddIn_Startup(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Startup
        ' Start of VSTO generated code

        Me.Application = CType(Microsoft.Office.Tools.Excel.ExcelLocale1033Proxy.Wrap(GetType(Excel.Application), Me.Application), Excel.Application)

        ' End of VSTO generated code
        Dim MyTaskPane As New HRTaskPane
        Dim MyCustomTaskPane As Microsoft.Office.Tools.CustomTaskPane = _
        Me.CustomTaskPanes.Add(MyTaskPane, "HR Tasks")
        MyCustomTaskPane.Visible = True

    End Sub

    Private Sub ThisAddIn_Shutdown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shutdown

    End Sub

End class
