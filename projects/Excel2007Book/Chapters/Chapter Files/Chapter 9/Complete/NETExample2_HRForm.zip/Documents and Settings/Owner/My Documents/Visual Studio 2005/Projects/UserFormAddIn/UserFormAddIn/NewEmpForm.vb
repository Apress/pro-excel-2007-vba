Public Class NewEmpForm

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        FormatForm()
        PlaceData()
        Close()
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Close()
    End Sub

    Private Sub FormatForm()
        DoHeadings()
        Dim rng As Excel.Range
        With Globals.ThisAddIn.Application
            rng = .Range("A5")
            rng.Value = "First Name"
            rng.Font.Bold = True
            rng.ColumnWidth = 15
            rng = .Range("B5")
            rng.Value = "Mid Init"
            rng.Font.Bold = True
            rng.ColumnWidth = 15
            rng = .Range("C5")
            rng.Value = "Last Name"
            rng.Font.Bold = True
            rng.ColumnWidth = 15
            rng = .Range("A8")
            rng.Value = "Date of Hire"
            rng.Font.Bold = True
            rng = .Range("B8")
            rng.Value = "Job Title"
            rng.Font.Bold = True
            rng = .Range("C8")
            rng.Value = "Reports To"
            rng.Font.Bold = True
        End With
        rng = Nothing
    End Sub

    Private Sub DoHeadings()
        Dim rng As Excel.Range
        With Globals.ThisAddIn.Application
            rng = .Range("A1")
            rng.Value = "HR Data Entry System"
            rng.Font.Bold = True
            rng.Font.Size = 16
            rng = .Range("A2")
            rng.Value = "New Employee Information"
            rng.Font.Italic = True
            rng.Font.Size = 14
        End With
        rng = Nothing
    End Sub

    Private Sub PlaceData()
        Dim rng As Excel.Range
        With Globals.ThisAddIn.Application
            rng = .Range("A6")
            rng.Value = Me.txtFName.Text
            rng = .Range("B6")
            rng.Value = Me.txtMidInit.Text
            rng = .Range("C6")
            rng.Value = Me.txtLName.Text
            rng = .Range("A9")
            rng.Value = Me.txtDOH.Text
            rng = .Range("B9")
            rng.Value = Me.txtTitle.Text
            rng = .Range("C9")
            rng.Value = Me.txtReportsTo.Text
        End With
    End Sub
End Class