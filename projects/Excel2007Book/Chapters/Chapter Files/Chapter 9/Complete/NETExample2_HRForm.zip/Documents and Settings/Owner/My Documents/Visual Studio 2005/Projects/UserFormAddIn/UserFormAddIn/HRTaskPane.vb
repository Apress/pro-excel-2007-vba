Public Class HRTaskPane

    Private Sub btnLaunch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLaunch.Click
        Dim oForm As New NewEmpForm
        oForm.ShowDialog()
    End Sub

    Private Sub btnEmail_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEmail.Click
        Dim rng As Excel.Range
        rng = Globals.ThisAddIn.Application.Range("A6")
        'code to handle e-mail here
        MsgBox("Sending new hire information for" & rng.Text & " to Systems Group")
    End Sub
End Class
