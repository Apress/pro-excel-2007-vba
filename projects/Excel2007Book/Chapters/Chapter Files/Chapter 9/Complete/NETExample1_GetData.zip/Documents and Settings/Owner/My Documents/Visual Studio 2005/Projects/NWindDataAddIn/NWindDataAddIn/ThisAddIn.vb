
public class ThisAddIn
    Private m_oNWind As NWindDataAccess.NWindData
    Private m_oSheet As Excel.Worksheet
    Private m_oDS As DataSet
    '
    Private Sub ThisAddIn_Startup(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Startup
        ' Start of VSTO generated code

        Me.Application = CType(Microsoft.Office.Tools.Excel.ExcelLocale1033Proxy.Wrap(GetType(Excel.Application), Me.Application), Excel.Application)

        ' End of VSTO generated code
        m_oNWind = New NWindDataAccess.NWindData
        m_oSheet = Me.Application.Worksheets("Sheet1")
        GetData()
    End Sub

    Private Sub ThisAddIn_Shutdown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shutdown

    End Sub

    Private Sub GetData()
        Dim sDB As String = "C:\ExampleDBs\Northwind 2007.accdb"
        Dim iCols As Integer
        Dim i As Integer
        Dim row As Integer

        Try
            With m_oNWind
                .NwindPathFileName = sDB
                m_oDS = .GetData("select * from employees")
            End With

            iCols = m_oDS.Tables("Table1").Columns.Count
            For i = 0 To iCols - 1
                m_oSheet.Cells(1, i + 1).Value = _
                                        m_oDS.Tables("Table1").Columns(i).Caption
            Next

            row = 2
            For Each RowIterator As DataRow In m_oDS.Tables("Table1").Rows
                For i = 0 To iCols - 1
                    m_oSheet.Cells(row, i + 1).Value = _
                            RowIterator(m_oDS.Tables("Table1").Columns(i).Caption)
                Next
                row = row + 1
            Next

            Dim r As Excel.Range
            m_oSheet.Select()
            r = m_oSheet.Range("A1")
            r.Select()
            Application.Selection.Currentregion.Select()
            Application.Selection.Columns.Autofit()
            r.Select()
        Catch ex As System.IO.FileNotFoundException
            MsgBox("File: " & sDB & " not found")
        Catch ex As Exception

        End Try
    End Sub

End class
