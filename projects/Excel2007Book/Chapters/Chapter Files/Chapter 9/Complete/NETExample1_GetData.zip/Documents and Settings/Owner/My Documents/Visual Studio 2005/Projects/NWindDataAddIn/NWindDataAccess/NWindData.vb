Imports System.Data.OleDb
Public Class NWindData
    Const TABLE_NAME As String = "Table1"
    Private m_sNwindName As String
    '
    Public Property NwindPathFileName() As String
        Get
            Return m_sNwindName
        End Get
        Set(ByVal value As String)
            If System.IO.File.Exists(value) Then
                m_sNwindName = value
            Else
                Throw New System.IO.FileNotFoundException
            End If
        End Set
    End Property

    Public Function GetData(ByVal Which As String) As DataSet
        Dim dsReturn As New DataSet()
        Dim cnn As OleDbConnection
        Dim sConnString As String

        sConnString = "Provider=Microsoft.ACE.OLEDB.12.0;" _
                    & "Data Source=" & m_sNwindName & ";"
        cnn = New OleDb.OleDbConnection(sConnString)

        Dim da As New OleDbDataAdapter(Which, cnn)

        Try
            da.Fill(dsReturn, TABLE_NAME)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

        Return dsReturn
    End Function

End Class
